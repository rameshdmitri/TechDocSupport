# Sgi — Console de execução de stored procedures por código de sistema

Console application **.NET 8** que recebe um **código de sistema** e executa a stored
procedure correspondente no banco certo (**SQL Server** ou **Oracle**), com mapeamento
dirigido por configuração e **auditoria de cada execução** num store de controle.

Arquitetura em Clean Architecture, adaptada da `constitution.md` do StartPlanning-Api.

## Decisões fixadas

- **AutoMapper** para projetar o resultado da execução em DTO.
- **Sem `IUnitOfWork`**: a execução das SPs usa Dapper sem DbContext; o repositório de
  auditoria usa o `AppDbContext` diretamente e fecha a própria escrita.
- **Console application**: sem JWT, controllers, Swagger, CORS ou versionamento. O análogo
  de `ApiControllerBase.HandleResult` é o `ExitCodeMapper`.
- **Auditoria write-only**: não há comando de leitura/listagem. Cada execução grava um registro.

## Auditoria de execuções

Toda execução que chega a um código válido grava um registro em `ExecutionAudits`
(banco `SgiControl`, SQL Server) com, entre outros campos:

- `SystemCode` — o parâmetro recebido pelo console.
- `Parameters` — os parâmetros de execução (JSON).
- `RowsReturned` — linhas retornadas/afetadas pela procedure.
- `Success` + `ErrorCode`/`ErrorDescription` — se a execução teve sucesso ou não.
- `Provider`, `StoredProcedureName`, `StartedAt`, `ElapsedMs`, `HostName`, `CreatedAt`.

Detalhes: a entidade `ExecutionAudit` implementa `IEntityMarker`; a `ExecutionAuditConfiguration`
(`IEntityTypeConfiguration<>`) é auto-descoberta por reflexão no `AppDbContext`. A gravação é
best-effort — uma falha de auditoria não mascara o resultado da execução.

Criar a tabela: rode `db/001_create_execution_audit.sql` ou
`dotnet ef migrations add InitialControl && dotnet ef database update`.

## Camadas e regra de dependência

```
Sgi.Console (composition root)  → Application (+ Persistence só para DI)
Sgi.Application                 → Domain
Sgi.Persistence                 → Application, Domain
Sgi.Domain                      → (zero dependências externas)
```

## Como rodar

```bash
dotnet build
dotnet run --project src/Sgi.Console -- VENDAS
```

Exit codes: `0` sucesso, `1` falha genérica, `2` argumento ausente, `3` validação,
`4` não encontrado, `5` conflito, `99` erro inesperado.

## Adicionar um novo sistema

Edite `src/Sgi.Console/appsettings.json` em `Systems:Items` — sem recompilar. O bloco
`Parameters` é gravado na auditoria a cada execução:

```json
"RH": {
  "Provider": "SqlServer",
  "ConnectionStringName": "RhDb",
  "StoredProcedure": "dbo.usp_ProcessarRH",
  "Parameters": { "competencia": "2026-06" }
}
```

## Observações

- **Segredos:** não deixe senha em `appsettings.json` em produção — use User Secrets,
  variáveis de ambiente ou um cofre.
- **Oracle:** o executor traz um comentário sobre `REF CURSOR` / OUT params — ajuste à
  assinatura real das suas procedures.
- **Versões de pacote** nos `.csproj` são compatíveis com .NET 8; rode `dotnet restore`
  e ajuste se necessário ao seu feed NuGet.
