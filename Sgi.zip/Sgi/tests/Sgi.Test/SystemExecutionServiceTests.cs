using AutoMapper;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Sgi.Application.Abstractions;
using Sgi.Application.Common.Errors;
using Sgi.Application.Common.Models;
using Sgi.Application.DTO.Request;
using Sgi.Application.DTO.Response;
using Sgi.Application.Models;
using Sgi.Application.Services;
using Sgi.Domain.Entities;
using Sgi.Domain.Enums;
using Sgi.Domain.ReadModels;
using Sgi.Domain.Repositories;
using Sgi.Domain.ValueObjects;

namespace Sgi.Test;

[TestClass]
public class SystemExecutionServiceTests
{
    private static (SystemExecutionService Sut, Mock<IExecutionAuditRepository> Audit) BuildSut(
        ISystemConfigurationProvider config,
        IStoredProcedureExecutorFactory? factory = null,
        IMapper? mapper = null)
    {
        var audit = new Mock<IExecutionAuditRepository>();
        var sut = new SystemExecutionService(
            config,
            factory ?? Mock.Of<IStoredProcedureExecutorFactory>(),
            audit.Object,
            mapper ?? Mock.Of<IMapper>(),
            Mock.Of<ILogger<SystemExecutionService>>());
        return (sut, audit);
    }

    [TestMethod]
    public async Task Should_ReturnValidation_And_NotAudit_When_SystemCodeIsBlank()
    {
        var (sut, audit) = BuildSut(Mock.Of<ISystemConfigurationProvider>());

        var result = await sut.ExecuteAsync(new ExecuteSystemRequestDto("   "));

        Assert.IsTrue(result.IsFailure);
        Assert.AreEqual("System.Validation", result.Error.Code);
        audit.Verify(a => a.AddAsync(It.IsAny<ExecutionAudit>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [TestMethod]
    public async Task Should_ReturnNotFound_And_AuditFailure_When_SystemIsNotConfigured()
    {
        var config = new Mock<ISystemConfigurationProvider>();
        config.Setup(c => c.TryGet(It.IsAny<SystemCode>()))
              .Returns(Result.Failure<SystemDefinition>(SystemErrors.NotConfigured("XPTO")));

        var (sut, audit) = BuildSut(config.Object);

        var result = await sut.ExecuteAsync(new ExecuteSystemRequestDto("XPTO"));

        Assert.IsTrue(result.IsFailure);
        Assert.AreEqual("System.NotFound", result.Error.Code);
        audit.Verify(a => a.AddAsync(
            It.Is<ExecutionAudit>(e => !e.Success && e.SystemCode == "XPTO"),
            It.IsAny<CancellationToken>()), Times.Once);
    }

    [TestMethod]
    public async Task Should_ReturnSuccess_And_AuditAllData_When_ExecutionCompletes()
    {
        var parameters = new Dictionary<string, object?> { ["dataReferencia"] = "2026-06-01" };
        var definition = new SystemDefinition(
            "VENDAS", DatabaseProvider.SqlServer, "conn", "dbo.usp_X", parameters);

        var config = new Mock<ISystemConfigurationProvider>();
        config.Setup(c => c.TryGet(It.IsAny<SystemCode>()))
              .Returns(Result.Success(definition));

        var executor = new Mock<IStoredProcedureExecutor>();
        executor.Setup(e => e.ExecuteAsync(
                    "conn", "dbo.usp_X",
                    It.IsAny<IReadOnlyDictionary<string, object?>>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(new StoredProcedureResult(3, 0, TimeSpan.FromMilliseconds(12)));

        var factory = new Mock<IStoredProcedureExecutorFactory>();
        factory.Setup(f => f.Create(DatabaseProvider.SqlServer)).Returns(executor.Object);

        var mapper = new Mock<IMapper>();
        mapper.Setup(m => m.Map<ExecutionResponseDto>(It.IsAny<StoredProcedureResult>()))
              .Returns(new ExecutionResponseDto(3, 0, 12));

        var (sut, audit) = BuildSut(config.Object, factory.Object, mapper.Object);

        var result = await sut.ExecuteAsync(new ExecuteSystemRequestDto("VENDAS"));

        Assert.IsTrue(result.IsSuccess);
        Assert.AreEqual(3, result.Value.RowsAffected);
        audit.Verify(a => a.AddAsync(
            It.Is<ExecutionAudit>(e =>
                e.Success &&
                e.SystemCode == "VENDAS" &&
                e.RowsReturned == 3 &&
                e.Parameters != null &&
                e.Parameters.Contains("dataReferencia")),
            It.IsAny<CancellationToken>()), Times.Once);
    }
}
