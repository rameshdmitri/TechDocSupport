-- Store de controle (SgiControl). Espelha Persistence/Configuration/ExecutionAuditConfiguration.cs.
-- Alternativa: usar EF Core migrations (dotnet ef migrations add InitialControl).

IF OBJECT_ID(N'[dbo].[ExecutionAudits]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[ExecutionAudits]
    (
        [Id]                  INT IDENTITY(1,1) NOT NULL,
        [SystemCode]          NVARCHAR(50)   NOT NULL,
        [Provider]            NVARCHAR(20)   NULL,
        [StoredProcedureName] NVARCHAR(255)  NULL,
        [Parameters]          NVARCHAR(MAX)  NULL,   -- parâmetros de execução (JSON)
        [StartedAt]           DATETIME       NOT NULL,
        [ElapsedMs]           FLOAT          NOT NULL,
        [RowsReturned]        INT            NOT NULL,
        [ReturnCode]          INT            NOT NULL,
        [Success]             BIT            NOT NULL,
        [ErrorCode]           NVARCHAR(100)  NULL,
        [ErrorDescription]    NVARCHAR(500)  NULL,
        [HostName]            NVARCHAR(255)  NOT NULL,
        [CreatedAt]           DATETIME       NOT NULL,
        CONSTRAINT [PK_ExecutionAudits] PRIMARY KEY CLUSTERED ([Id] ASC)
    );

    CREATE INDEX [IX_ExecutionAudits_SystemCode] ON [dbo].[ExecutionAudits] ([SystemCode]);
    CREATE INDEX [IX_ExecutionAudits_CreatedAt]  ON [dbo].[ExecutionAudits] ([CreatedAt]);
END
