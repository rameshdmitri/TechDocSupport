namespace Sgi.Domain.Abstractions;

/// <summary>
/// Interface marcadora base para entidades de domínio (constitution §2).
/// Sem uso ainda — este console não persiste entidades próprias.
/// Mantida para que, ao adicionar uma tabela (ex.: auditoria de execuções),
/// a convenção já esteja disponível como restrição genérica de repositório.
/// </summary>
public interface IEntityMarker;
