namespace Sgi.Domain.ValueObjects;

/// <summary>
/// Código de sistema normalizado. Falha de validação é esperada, então não
/// lança exception (constitution §4): use <see cref="TryCreate"/> e devolva Result no serviço.
/// </summary>
public sealed record SystemCode
{
    public string Value { get; }

    private SystemCode(string value) => Value = value;

    public static bool TryCreate(string? raw, out SystemCode? code)
    {
        code = null;
        if (string.IsNullOrWhiteSpace(raw))
            return false;

        code = new SystemCode(raw.Trim().ToUpperInvariant());
        return true;
    }

    public override string ToString() => Value;
}
