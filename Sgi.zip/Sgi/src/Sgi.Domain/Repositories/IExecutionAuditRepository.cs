using Sgi.Domain.Entities;

namespace Sgi.Domain.Repositories;

/// <summary>
/// Repositório write-only do store de controle (constitution §3). Sem IUnitOfWork:
/// a implementação fecha a própria escrita. A auditoria registra toda execução.
/// </summary>
public interface IExecutionAuditRepository
{
    Task AddAsync(ExecutionAudit audit, CancellationToken cancellationToken);
}
