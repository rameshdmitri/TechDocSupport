using Sgi.Domain.Enums;
using Sgi.Domain.ReadModels;

namespace Sgi.Domain.Repositories;

/// <summary>
/// Porta de acesso a dados (constitution §3 — interfaces de repositório vivem no Domain).
/// Cada implementação concreta na camada Persistence atende um <see cref="DatabaseProvider"/>.
/// </summary>
public interface IStoredProcedureExecutor
{
    DatabaseProvider Provider { get; }

    Task<StoredProcedureResult> ExecuteAsync(
        string connectionString,
        string storedProcedureName,
        IReadOnlyDictionary<string, object?> parameters,
        CancellationToken cancellationToken);
}
