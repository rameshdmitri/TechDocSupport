namespace Sgi.Domain.ReadModels;

/// <summary>
/// Projeção desnormalizada do resultado de execução de uma stored procedure
/// (constitution §2 — ReadModels). Não é entidade persistida.
/// </summary>
public sealed record StoredProcedureResult(
    int RowsAffected,
    int ReturnCode,
    TimeSpan Elapsed);
