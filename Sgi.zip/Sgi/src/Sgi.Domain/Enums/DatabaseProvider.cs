namespace Sgi.Domain.Enums;

public enum DatabaseProvider
{
    SqlServer,
    Oracle
}
