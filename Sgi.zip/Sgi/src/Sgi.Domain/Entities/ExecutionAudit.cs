using Sgi.Domain.Abstractions;
using Sgi.Domain.Enums;

namespace Sgi.Domain.Entities;

/// <summary>
/// Registro de auditoria de uma execução (constitution §2). Grava, por execução:
/// o código de sistema, os parâmetros de execução (JSON), as linhas retornadas pela
/// procedure, o código de retorno e se a execução teve sucesso ou não.
/// </summary>
public sealed class ExecutionAudit : IEntityMarker
{
    public int Id { get; set; }
    public string SystemCode { get; set; } = default!;
    public DatabaseProvider? Provider { get; set; }
    public string? StoredProcedureName { get; set; }

    /// <summary>Parâmetros de execução serializados em JSON.</summary>
    public string? Parameters { get; set; }

    public DateTime StartedAt { get; set; }
    public double ElapsedMs { get; set; }

    /// <summary>Linhas retornadas/afetadas pela procedure.</summary>
    public int RowsReturned { get; set; }

    public int ReturnCode { get; set; }
    public bool Success { get; set; }
    public string? ErrorCode { get; set; }
    public string? ErrorDescription { get; set; }
    public string HostName { get; set; } = default!;
    public DateTime CreatedAt { get; set; }

    public static ExecutionAudit ForSuccess(
        string systemCode,
        DatabaseProvider provider,
        string storedProcedureName,
        string? parameters,
        DateTime startedAt,
        double elapsedMs,
        int rowsReturned,
        int returnCode,
        string hostName) => new()
    {
        SystemCode = systemCode,
        Provider = provider,
        StoredProcedureName = storedProcedureName,
        Parameters = parameters,
        StartedAt = startedAt,
        ElapsedMs = elapsedMs,
        RowsReturned = rowsReturned,
        ReturnCode = returnCode,
        Success = true,
        HostName = hostName,
        CreatedAt = DateTime.UtcNow
    };

    public static ExecutionAudit ForFailure(
        string systemCode,
        DatabaseProvider? provider,
        string? storedProcedureName,
        string? parameters,
        DateTime startedAt,
        double elapsedMs,
        string errorCode,
        string errorDescription,
        string hostName) => new()
    {
        SystemCode = systemCode,
        Provider = provider,
        StoredProcedureName = storedProcedureName,
        Parameters = parameters,
        StartedAt = startedAt,
        ElapsedMs = elapsedMs,
        Success = false,
        ErrorCode = Truncate(errorCode, 100),
        ErrorDescription = Truncate(errorDescription, 500),
        HostName = hostName,
        CreatedAt = DateTime.UtcNow
    };

    private static string Truncate(string value, int max) =>
        value.Length <= max ? value : value[..max];
}
