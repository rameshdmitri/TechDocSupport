using Sgi.Application.Common.Models;

namespace Sgi.Application.Common.Errors;

/// <summary>
/// Catálogo de erros do domínio de execução (constitution §4).
/// Convenção de código: "Dominio.Tipo" — o sufixo controla o exit code.
/// </summary>
public static class SystemErrors
{
    public static readonly Error InvalidCode =
        new("System.Validation", "Código de sistema inválido ou ausente.");

    public static Error NotConfigured(string code) =>
        new("System.NotFound", $"Sistema '{code}' não está configurado.");

    public static Error ConnectionStringMissing(string name) =>
        new("System.NotFound", $"Connection string '{name}' não encontrada.");

    public static readonly Error ExecutionFailed =
        new("System.Conflict", "Falha ao executar a stored procedure.");
}
