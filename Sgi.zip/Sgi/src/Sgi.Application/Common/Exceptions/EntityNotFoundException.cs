namespace Sgi.Application.Common.Exceptions;

/// <summary>
/// Falha inesperada (constitution §4): recurso interno ausente por id.
/// Falhas esperadas (validação, negócio) usam Result/Fail, nunca exceptions.
/// </summary>
public sealed class EntityNotFoundException(string entityName, object id)
    : Exception($"{entityName} com id '{id}' não foi encontrado.")
{
    public string EntityName { get; } = entityName;
    public object Id { get; } = id;
}
