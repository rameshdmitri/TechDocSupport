namespace Sgi.Application.Common.Models;

/// <summary>
/// Erro nomeado (constitution §6). O sufixo do <see cref="Code"/> ("Dominio.Tipo")
/// controla o desfecho — no console, o exit code (ver Sgi.Console/Common/ExitCodeMapper).
/// </summary>
public sealed record Error(string Code, string Description)
{
    public static readonly Error None = new("", "");
    public static readonly Error NullValue = new("Error.NullValue", "A null value was provided.");
}
