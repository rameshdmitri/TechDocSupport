using Sgi.Domain.Enums;
using Sgi.Domain.Repositories;

namespace Sgi.Application.Abstractions;

/// <summary>
/// Resolve o executor concreto pelo provider (keyed services no contêiner de DI).
/// </summary>
public interface IStoredProcedureExecutorFactory
{
    IStoredProcedureExecutor Create(DatabaseProvider provider);
}
