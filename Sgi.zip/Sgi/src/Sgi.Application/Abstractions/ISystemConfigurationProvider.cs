using Sgi.Application.Common.Models;
using Sgi.Application.Models;
using Sgi.Domain.ValueObjects;

namespace Sgi.Application.Abstractions;

/// <summary>
/// Resolve um <see cref="SystemCode"/> para sua <see cref="SystemDefinition"/>.
/// Implementação concreta na camada Persistence (lê appsettings).
/// </summary>
public interface ISystemConfigurationProvider
{
    Result<SystemDefinition> TryGet(SystemCode code);
}
