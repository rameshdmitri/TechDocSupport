using AutoMapper;
using Sgi.Application.DTO.Response;
using Sgi.Domain.ReadModels;

namespace Sgi.Application.Mapping;

/// <summary>
/// Profile AutoMapper auto-descoberto via AddMaps(assembly) (constitution §7).
/// </summary>
public sealed class ExecutionProfile : Profile
{
    public ExecutionProfile() =>
        CreateMap<StoredProcedureResult, ExecutionResponseDto>()
            .ForCtorParam(
                nameof(ExecutionResponseDto.ElapsedMs),
                o => o.MapFrom(s => s.Elapsed.TotalMilliseconds));
}
