using Sgi.Application.Common.Models;
using Sgi.Application.DTO.Request;
using Sgi.Application.DTO.Response;

namespace Sgi.Application.Services.Interfaces;

public interface ISystemExecutionService
{
    Task<Result<ExecutionResponseDto>> ExecuteAsync(
        ExecuteSystemRequestDto request,
        CancellationToken ct = default);
}
