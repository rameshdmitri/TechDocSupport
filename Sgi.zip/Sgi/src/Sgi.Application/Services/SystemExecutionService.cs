using System.Diagnostics;
using System.Text.Json;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Sgi.Application.Abstractions;
using Sgi.Application.Common.Errors;
using Sgi.Application.Common.Models;
using Sgi.Application.DTO.Request;
using Sgi.Application.DTO.Response;
using Sgi.Domain.Entities;
using Sgi.Domain.Repositories;
using Sgi.Domain.ValueObjects;

namespace Sgi.Application.Services;

/// <summary>
/// Orquestra a execução e grava auditoria de TODA tentativa que chega a um código válido,
/// registrando os parâmetros de execução, as linhas retornadas e se houve sucesso (constitution §4).
/// </summary>
public sealed class SystemExecutionService(
    ISystemConfigurationProvider configurationProvider,
    IStoredProcedureExecutorFactory executorFactory,
    IExecutionAuditRepository auditRepository,
    IMapper mapper,
    ILogger<SystemExecutionService> logger)
    : BaseService, ISystemExecutionService
{
    public async Task<Result<ExecutionResponseDto>> ExecuteAsync(
        ExecuteSystemRequestDto request,
        CancellationToken ct = default)
    {
        if (!SystemCode.TryCreate(request.SystemCode, out var code))
            return Fail<ExecutionResponseDto>(SystemErrors.InvalidCode);

        var startedAt = DateTime.UtcNow;
        var stopwatch = Stopwatch.StartNew();

        var lookup = configurationProvider.TryGet(code!);
        if (lookup.IsFailure)
        {
            await WriteAuditAsync(ExecutionAudit.ForFailure(
                code!.Value, null, null, null, startedAt, stopwatch.Elapsed.TotalMilliseconds,
                lookup.Error.Code, lookup.Error.Description, Environment.MachineName), ct);

            return Fail<ExecutionResponseDto>(lookup.Error);
        }

        var definition = lookup.Value;
        var parametersJson = JsonSerializer.Serialize(definition.Parameters);

        logger.LogInformation(
            "Sistema {SystemCode} resolvido para {Provider} / {StoredProcedure}.",
            code!.Value, definition.Provider, definition.StoredProcedureName);

        try
        {
            var result = await executorFactory
                .Create(definition.Provider)
                .ExecuteAsync(
                    definition.ConnectionString,
                    definition.StoredProcedureName,
                    definition.Parameters,
                    ct);

            await WriteAuditAsync(ExecutionAudit.ForSuccess(
                code.Value, definition.Provider, definition.StoredProcedureName, parametersJson,
                startedAt, result.Elapsed.TotalMilliseconds,
                result.RowsAffected, result.ReturnCode, Environment.MachineName), ct);

            return Ok(mapper.Map<ExecutionResponseDto>(result));
        }
        catch (Exception ex)
        {
            // Falha de infraestrutura (ex.: erro da própria SP). Auditamos, traduzimos para
            // um Result de negócio e seguimos — não deixamos a exceção subir crua.
            logger.LogError(ex,
                "Falha ao executar {StoredProcedure} para {SystemCode}.",
                definition.StoredProcedureName, code.Value);

            await WriteAuditAsync(ExecutionAudit.ForFailure(
                code.Value, definition.Provider, definition.StoredProcedureName, parametersJson,
                startedAt, stopwatch.Elapsed.TotalMilliseconds,
                SystemErrors.ExecutionFailed.Code, ex.Message, Environment.MachineName), ct);

            return Fail<ExecutionResponseDto>(SystemErrors.ExecutionFailed);
        }
    }

    /// <summary>
    /// Gravação best-effort: uma falha no store de controle não pode mascarar o resultado da execução.
    /// </summary>
    private async Task WriteAuditAsync(ExecutionAudit audit, CancellationToken ct)
    {
        try
        {
            await auditRepository.AddAsync(audit, ct);
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex,
                "Não foi possível gravar a auditoria de execução para {SystemCode}.",
                audit.SystemCode);
        }
    }
}
