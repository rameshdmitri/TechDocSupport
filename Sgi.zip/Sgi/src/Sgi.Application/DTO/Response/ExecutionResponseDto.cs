namespace Sgi.Application.DTO.Response;

public sealed record ExecutionResponseDto(
    int RowsAffected,
    int ReturnCode,
    double ElapsedMs);
