namespace Sgi.Application.DTO.Request;

public sealed record ExecuteSystemRequestDto(string SystemCode);
