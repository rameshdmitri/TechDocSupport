using Microsoft.Extensions.DependencyInjection;
using Sgi.Application.Services;
using Sgi.Application.Services.Interfaces;

namespace Sgi.Application.Configuration;

/// <summary>
/// DI da camada Application (constitution §10): AutoMapper + serviços como Scoped.
/// </summary>
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {
        services.AddAutoMapper(cfg =>
            cfg.AddMaps(typeof(ServiceCollectionExtensions).Assembly));

        services.AddScoped<ISystemExecutionService, SystemExecutionService>();

        return services;
    }
}
