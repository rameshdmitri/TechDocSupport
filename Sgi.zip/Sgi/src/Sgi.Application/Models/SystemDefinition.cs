using Sgi.Domain.Enums;

namespace Sgi.Application.Models;

/// <summary>
/// Configuração resolvida de um código de sistema: provider, conexão, SP e parâmetros.
/// </summary>
public sealed record SystemDefinition(
    string SystemCode,
    DatabaseProvider Provider,
    string ConnectionString,
    string StoredProcedureName,
    IReadOnlyDictionary<string, object?> Parameters);
