using Sgi.Domain.Enums;

namespace Sgi.Persistence.Configuration;

/// <summary>
/// Mapeamento dirigido por configuração (appsettings "Systems:Items").
/// Adicionar um sistema novo não exige recompilar.
/// </summary>
public sealed class SystemMappingOptions
{
    public const string SectionName = "Systems";

    public Dictionary<string, SystemEntry> Items { get; init; } = new();
}

public sealed class SystemEntry
{
    public DatabaseProvider Provider { get; init; }
    public string ConnectionStringName { get; init; } = default!;
    public string StoredProcedure { get; init; } = default!;
    public Dictionary<string, object?> Parameters { get; init; } = new();
}
