using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sgi.Domain.Entities;

namespace Sgi.Persistence.Configuration;

/// <summary>
/// Configuração EF da auditoria seguindo as convenções de tipo da constitution §2.
/// Auto-descoberta por reflexão no AppDbContext — não registrar manualmente.
/// </summary>
public sealed class ExecutionAuditConfiguration : IEntityTypeConfiguration<ExecutionAudit>
{
    public void Configure(EntityTypeBuilder<ExecutionAudit> builder)
    {
        builder.ToTable("ExecutionAudits");

        builder.HasKey(e => e.Id);
        builder.Property(e => e.Id).UseIdentityColumn();            // int IDENTITY

        builder.Property(e => e.SystemCode).HasMaxLength(50).IsRequired();
        builder.Property(e => e.Provider).HasConversion<string>().HasMaxLength(20);
        builder.Property(e => e.StoredProcedureName).HasMaxLength(255);
        builder.Property(e => e.Parameters).HasColumnType("nvarchar(max)");   // JSON dos parâmetros
        builder.Property(e => e.StartedAt).IsRequired();            // datetime
        builder.Property(e => e.ElapsedMs).IsRequired();
        builder.Property(e => e.RowsReturned).IsRequired();
        builder.Property(e => e.ReturnCode).IsRequired();
        builder.Property(e => e.Success).IsRequired();
        builder.Property(e => e.ErrorCode).HasMaxLength(100);
        builder.Property(e => e.ErrorDescription).HasMaxLength(500);
        builder.Property(e => e.HostName).HasMaxLength(255).IsRequired();
        builder.Property(e => e.CreatedAt).IsRequired();            // datetime

        builder.HasIndex(e => e.SystemCode);
        builder.HasIndex(e => e.CreatedAt);
    }
}
