using System.Data.Common;
using Sgi.Domain.Enums;

namespace Sgi.Persistence.Connections;

public interface IDbConnectionFactory
{
    DatabaseProvider Provider { get; }
    DbConnection Create(string connectionString);
}
