using System.Data.Common;
using Oracle.ManagedDataAccess.Client;
using Sgi.Domain.Enums;

namespace Sgi.Persistence.Connections;

public sealed class OracleConnectionFactory : IDbConnectionFactory
{
    public DatabaseProvider Provider => DatabaseProvider.Oracle;
    public DbConnection Create(string connectionString) => new OracleConnection(connectionString);
}
