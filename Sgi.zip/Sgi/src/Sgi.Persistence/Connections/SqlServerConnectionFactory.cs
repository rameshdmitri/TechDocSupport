using System.Data.Common;
using Microsoft.Data.SqlClient;
using Sgi.Domain.Enums;

namespace Sgi.Persistence.Connections;

public sealed class SqlServerConnectionFactory : IDbConnectionFactory
{
    public DatabaseProvider Provider => DatabaseProvider.SqlServer;
    public DbConnection Create(string connectionString) => new SqlConnection(connectionString);
}
