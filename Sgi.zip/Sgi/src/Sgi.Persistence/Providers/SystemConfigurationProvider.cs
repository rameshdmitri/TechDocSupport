using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Sgi.Application.Abstractions;
using Sgi.Application.Common.Errors;
using Sgi.Application.Common.Models;
using Sgi.Application.Models;
using Sgi.Domain.ValueObjects;
using Sgi.Persistence.Configuration;

namespace Sgi.Persistence.Providers;

/// <summary>
/// Lê o mapeamento de "Systems:Items" e resolve a connection string em ConnectionStrings.
/// Componente de infraestrutura: usa Result.Failure/Success direto (não é serviço da Application).
/// </summary>
public sealed class SystemConfigurationProvider(
    IOptions<SystemMappingOptions> options,
    IConfiguration configuration)
    : ISystemConfigurationProvider
{
    public Result<SystemDefinition> TryGet(SystemCode code)
    {
        if (!options.Value.Items.TryGetValue(code.Value, out var entry))
            return Result.Failure<SystemDefinition>(SystemErrors.NotConfigured(code.Value));

        var connectionString = configuration.GetConnectionString(entry.ConnectionStringName);
        if (string.IsNullOrWhiteSpace(connectionString))
            return Result.Failure<SystemDefinition>(
                SystemErrors.ConnectionStringMissing(entry.ConnectionStringName));

        return Result.Success(new SystemDefinition(
            code.Value,
            entry.Provider,
            connectionString,
            entry.StoredProcedure,
            entry.Parameters));
    }
}
