using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Sgi.Application.Abstractions;
using Sgi.Domain.Enums;
using Sgi.Domain.Repositories;
using Sgi.Persistence.Configuration;
using Sgi.Persistence.Connections;
using Sgi.Persistence.Context;
using Sgi.Persistence.Providers;
using Sgi.Persistence.Repositories;

namespace Sgi.Persistence;

/// <summary>
/// DI da camada Persistence (constitution §10).
/// Execução de SP: Dapper + keyed services, sem DbContext (bancos heterogêneos).
/// Store de controle: EF Core sobre um único banco SQL Server ("ControlDb"), sem IUnitOfWork.
/// </summary>
public static class DependencyInjection
{
    public static IServiceCollection AddPersistence(
        this IServiceCollection services,
        IConfiguration config)
    {
        // --- Execução de stored procedures (Dapper, multi-provider) ---
        services.Configure<SystemMappingOptions>(
            config.GetSection(SystemMappingOptions.SectionName));

        services.AddSingleton<SqlServerConnectionFactory>();
        services.AddSingleton<OracleConnectionFactory>();

        services.AddKeyedScoped<IStoredProcedureExecutor, SqlServerStoredProcedureExecutor>(
            DatabaseProvider.SqlServer);
        services.AddKeyedScoped<IStoredProcedureExecutor, OracleStoredProcedureExecutor>(
            DatabaseProvider.Oracle);

        services.AddScoped<IStoredProcedureExecutorFactory, StoredProcedureExecutorFactory>();
        services.AddScoped<ISystemConfigurationProvider, SystemConfigurationProvider>();

        // --- Store de controle / auditoria (EF Core, banco único) ---
        services.AddDbContext<AppDbContext>(opt =>
            opt.UseSqlServer(config.GetConnectionString("ControlDb")));

        services.AddScoped<IExecutionAuditRepository, ExecutionAuditRepository>();

        return services;
    }
}
