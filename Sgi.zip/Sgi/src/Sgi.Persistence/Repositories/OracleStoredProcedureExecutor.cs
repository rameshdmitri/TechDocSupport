using System.Data;
using Dapper;
using Sgi.Domain.Enums;
using Sgi.Domain.ReadModels;
using Sgi.Domain.Repositories;
using Sgi.Persistence.Connections;

namespace Sgi.Persistence.Repositories;

public sealed class OracleStoredProcedureExecutor(
    OracleConnectionFactory connectionFactory)
    : IStoredProcedureExecutor
{
    public DatabaseProvider Provider => DatabaseProvider.Oracle;

    public async Task<StoredProcedureResult> ExecuteAsync(
        string connectionString,
        string storedProcedureName,
        IReadOnlyDictionary<string, object?> parameters,
        CancellationToken cancellationToken)
    {
        await using var connection = connectionFactory.Create(connectionString);

        var p = new DynamicParameters();
        foreach (var (name, value) in parameters)
            p.Add(name, value);

        // Oracle costuma expor retorno via OUT param ou REF CURSOR. Ajuste conforme a
        // assinatura real, por exemplo usando OracleDynamicParameters para um cursor:
        //   p.Add("p_cursor", dbType: OracleMappingType.RefCursor, direction: ParameterDirection.Output);
        var startedAt = TimeProvider.System.GetTimestamp();

        var command = new CommandDefinition(
            storedProcedureName,
            p,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken);

        var rows = await connection.ExecuteAsync(command);

        return new StoredProcedureResult(
            RowsAffected: rows,
            ReturnCode: 0,
            Elapsed: TimeProvider.System.GetElapsedTime(startedAt));
    }
}
