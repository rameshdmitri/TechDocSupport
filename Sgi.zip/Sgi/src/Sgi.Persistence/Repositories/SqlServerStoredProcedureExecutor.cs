using System.Data;
using Dapper;
using Sgi.Domain.Enums;
using Sgi.Domain.ReadModels;
using Sgi.Domain.Repositories;
using Sgi.Persistence.Connections;

namespace Sgi.Persistence.Repositories;

public sealed class SqlServerStoredProcedureExecutor(
    SqlServerConnectionFactory connectionFactory)
    : IStoredProcedureExecutor
{
    public DatabaseProvider Provider => DatabaseProvider.SqlServer;

    public async Task<StoredProcedureResult> ExecuteAsync(
        string connectionString,
        string storedProcedureName,
        IReadOnlyDictionary<string, object?> parameters,
        CancellationToken cancellationToken)
    {
        await using var connection = connectionFactory.Create(connectionString);

        var p = new DynamicParameters();
        foreach (var (name, value) in parameters)
            p.Add(name, value);

        p.Add("ReturnValue", dbType: DbType.Int32, direction: ParameterDirection.ReturnValue);

        var startedAt = TimeProvider.System.GetTimestamp();

        var command = new CommandDefinition(
            storedProcedureName,
            p,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken);

        var rows = await connection.ExecuteAsync(command);

        return new StoredProcedureResult(
            RowsAffected: rows,
            ReturnCode: p.Get<int>("ReturnValue"),
            Elapsed: TimeProvider.System.GetElapsedTime(startedAt));
    }
}
