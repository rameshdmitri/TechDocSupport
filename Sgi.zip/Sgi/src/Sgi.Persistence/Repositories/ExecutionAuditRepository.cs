using Sgi.Domain.Entities;
using Sgi.Domain.Repositories;
using Sgi.Persistence.Context;

namespace Sgi.Persistence.Repositories;

/// <summary>
/// Write-only. Sem IUnitOfWork: usa o DbContext diretamente e fecha a escrita com
/// SaveChangesAsync. Os serviços nunca tocam o DbContext (constitution §3, adaptado).
/// </summary>
public sealed class ExecutionAuditRepository(AppDbContext context) : IExecutionAuditRepository
{
    public async Task AddAsync(ExecutionAudit audit, CancellationToken cancellationToken)
    {
        await context.ExecutionAudits.AddAsync(audit, cancellationToken);
        await context.SaveChangesAsync(cancellationToken);
    }
}
