using Microsoft.Extensions.DependencyInjection;
using Sgi.Application.Abstractions;
using Sgi.Domain.Enums;
using Sgi.Domain.Repositories;

namespace Sgi.Persistence.Repositories;

/// <summary>
/// Resolve o executor concreto via keyed services (constitution §3/§10).
/// </summary>
public sealed class StoredProcedureExecutorFactory(IServiceProvider serviceProvider)
    : IStoredProcedureExecutorFactory
{
    public IStoredProcedureExecutor Create(DatabaseProvider provider) =>
        serviceProvider.GetRequiredKeyedService<IStoredProcedureExecutor>(provider);
}
