using Microsoft.EntityFrameworkCore;
using Sgi.Domain.Entities;

namespace Sgi.Persistence.Context;

/// <summary>
/// Contexto do store de CONTROLE (auditoria). É um banco único e homogêneo (SQL Server),
/// totalmente separado das conexões heterogêneas usadas para executar as SPs via Dapper.
/// Não herda de IdentityDbContext: este console não tem autenticação (constitution §11, adaptado).
/// </summary>
public sealed class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<ExecutionAudit> ExecutionAudits => Set<ExecutionAudit>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.ApplyConfigurationsFromAssembly(
            typeof(EntityConfigurationsAssemblyAnchor).Assembly);
    }
}
