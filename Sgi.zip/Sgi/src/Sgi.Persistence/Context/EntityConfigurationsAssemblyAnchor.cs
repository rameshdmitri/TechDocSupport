namespace Sgi.Persistence.Context;

/// <summary>
/// Âncora para auto-descoberta por reflexão das IEntityTypeConfiguration (constitution §2/§11).
/// Não registre configurações manualmente — elas são aplicadas via ApplyConfigurationsFromAssembly.
/// </summary>
public interface EntityConfigurationsAssemblyAnchor;
