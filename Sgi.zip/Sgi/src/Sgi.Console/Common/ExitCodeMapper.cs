using Sgi.Application.Common.Models;

namespace Sgi.Console.Common;

/// <summary>
/// Análogo de ApiControllerBase.HandleResult (constitution §9): o sufixo do Error.Code
/// decide o desfecho. Aqui ele vira exit code, para compatibilidade com schedulers legados.
/// </summary>
internal static class ExitCodeMapper
{
    public const int Success = 0;
    public const int GenericFailure = 1;
    public const int MissingArgument = 2;
    public const int Validation = 3;
    public const int NotFound = 4;
    public const int Conflict = 5;
    public const int Unexpected = 99;

    public static int From<T>(Result<T> result) =>
        result.IsSuccess ? Success : FromError(result.Error);

    private static int FromError(Error error) => error.Code switch
    {
        var c when c.EndsWith(".NotFound", StringComparison.Ordinal) => NotFound,
        var c when c.EndsWith(".Conflict", StringComparison.Ordinal) => Conflict,
        var c when c.EndsWith(".Validation", StringComparison.Ordinal) => Validation,
        _ => GenericFailure
    };
}
