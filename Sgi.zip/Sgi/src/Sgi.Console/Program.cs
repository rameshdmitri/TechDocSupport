using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using Sgi.Application.Configuration;
using Sgi.Application.DTO.Request;
using Sgi.Application.Services.Interfaces;
using Sgi.Console.Common;
using Sgi.Persistence;

Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information()
    .WriteTo.Console()
    .CreateLogger();

try
{
    if (args.Length == 0)
    {
        Log.Error("Parâmetro de código de sistema é obrigatório. Uso: sgi <codigo>");
        return ExitCodeMapper.MissingArgument;
    }

    var builder = Host.CreateApplicationBuilder(args);
    builder.Services.AddSerilog();
    builder.Services.AddPersistence(builder.Configuration);   // cada camada expõe seu extension (constitution §10)
    builder.Services.AddApplicationServices();

    using var host = builder.Build();
    using var scope = host.Services.CreateScope();

    var service = scope.ServiceProvider.GetRequiredService<ISystemExecutionService>();

    var result = await service.ExecuteAsync(
        new ExecuteSystemRequestDto(args[0]),
        CancellationToken.None);

    if (result.IsFailure)
    {
        Log.Warning("Execução falhou. {ErrorCode}: {ErrorDescription}",
            result.Error.Code, result.Error.Description);
    }
    else
    {
        Log.Information(
            "Execução concluída. Linhas={RowsAffected} Retorno={ReturnCode} Tempo={ElapsedMs}ms",
            result.Value.RowsAffected, result.Value.ReturnCode, result.Value.ElapsedMs);
    }

    return ExitCodeMapper.From(result);
}
catch (Exception ex)
{
    Log.Fatal(ex, "Erro inesperado durante a execução.");
    return ExitCodeMapper.Unexpected;
}
finally
{
    Log.CloseAndFlush();
}
